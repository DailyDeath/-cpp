#FNPC
一款优秀的NPC插件,适合大部分服务器使用<br />
This is a great NPC plugin.<br />
<br />
使用方法请输入/fnpc help查看<br />
Type /fnpc help to display help message.<br />
<br />
捐赠链接:http://pl.zxda.net/plugins/11.html<br />
Donate link:http://pl.zxda.net/plugins/11.html<br />
<br />
注意,捐赠版和此版本无任何区别<br />
Donate version is same to this version.<br />
<br />
开源版本遵循GPL License(捐赠版不在此范围内)<br />
This version follow GPL License(Donate version NOT follow it).<br />

#联系方式
QQ:765569811,1943601164<br />
E-Mail:FENGberd@gmail.com<br />

#其他
如果你有兴趣请看提交记录ad3fbc9b09的README.md文件

